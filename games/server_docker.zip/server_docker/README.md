# Sample Game Server setup

Just make sure you installed mongodb in local, that's enough

Just run 
```
python3 server.py
```