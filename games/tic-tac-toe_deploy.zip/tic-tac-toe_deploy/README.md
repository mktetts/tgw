# Sample Tic Tac Toe Game
---

This is the sample Tic Tac Toe game where users can play from different blockchains with their own assets.

1. Just run the [server](../server/README.md) first.

2. And change the Game Id in .env file, if you create the game newely. Game Id is nothing but you created before uploading the game in Theta Game World Platform.

3. Run the app
```
npm run dev
```