import React from 'react'

function Assets() {
  return (
    <div>Assets</div>
  )
}

export default Assets